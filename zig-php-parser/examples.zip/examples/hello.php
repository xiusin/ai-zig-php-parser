<?php
// Basic Hello World example
echo "Hello, World!\n";

$name = "PHP 8.5 Interpreter";
echo "Welcome to {$name}!\n";

// Basic arithmetic
$a = 10;
$b = 20;
$sum = $a + $b;
echo "Sum: {$sum}\n";

// String operations
$greeting = "Hello";
$target = "World";
$message = $greeting . ", " . $target . "!";
echo $message . "\n";
?>