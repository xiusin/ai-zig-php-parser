<?php
$name = "Alice";

echo "Test 1: $name\n";
echo "Test 2: \$name\n";
echo "Test 3: \\$name\n";
