<?php
// 测试echo函数的多参数支持
echo "Hello", " ", "World", "\n";
echo "Multiple", " ", "parameters", " ", "work", "!\n";
echo "Numbers: ", 1, ", ", 2, ", ", 3, "\n";
echo "Mixed: ", "string", ", ", 42, ", ", true, "\n";
