<?php
$a = 1;
$a++;
echo "After increment: " . $a . "\n";
++$a;
echo "After pre-increment: " . $a . "\n";
