<?php
$a = -1;
echo "Negative: " . $a . "\n";
