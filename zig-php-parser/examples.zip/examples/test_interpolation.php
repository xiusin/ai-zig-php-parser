<?php
$name = "World";
echo "Hello {$name}!";
echo "Hello {$name}!";
// echo "Hello {$name}  ${name}!";
