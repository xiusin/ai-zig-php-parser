<?php
$a = 10;
$b = 20;
$sum = $a + $b;
echo $sum;
