<?php
echo "Test without closure\n";
$x = 10;
echo "x = " . $x . "\n";
?>
