<?php
function add($a, $b) {
    return $a + $b;
}

$x = 10;
$y = 20;
$result = add($x, $y);
echo $result;
