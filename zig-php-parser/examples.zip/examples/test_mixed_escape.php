<?php
$a = 1;
$b = 2;

// 测试混合使用变量插值和转义
echo "\$b = $b\n";
echo "\$a = $a and \$b = $b\n";
echo "Value: \$var = $a\n";
