<?php
echo "创建 Mutex\n";
$mutex = new Mutex();
echo "Mutex 类型: " . get_class($mutex) . "\n";
echo "完成\n";
