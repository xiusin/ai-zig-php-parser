<?php

echo "开始\n";
for {
    break;
}
echo "结束\n";
