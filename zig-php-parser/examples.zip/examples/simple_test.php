<?php
$x = 42;
echo $x;
