<?php

$null_var = null;
echo "Testing is_null: ";
echo is_null($null_var) ? "true" : "false";
echo "\n";

$empty_var = "";
echo "Testing empty: ";
echo empty($empty_var) ? "true" : "false";
echo "\n";

?>