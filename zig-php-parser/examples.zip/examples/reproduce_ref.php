<?php
$a = 1;
$b = &$a;
echo "Reference assignment done\n";
echo "\$b = $b \$a = $a\n";

echo  `sadasda

s$a`;