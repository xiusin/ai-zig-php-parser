<?php



$map = ["name" => "张三"];

echo "数组元素: ";
foreach ($map as $k=>$n) {
    echo  $k . " => " $n . " ";
}
echo "\n";

?>
