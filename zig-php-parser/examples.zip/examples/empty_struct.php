<?php

struct Point {
}

echo "Struct defined successfully!";