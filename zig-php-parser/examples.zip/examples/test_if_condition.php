<?php

for range 5 as $i {
    echo "i = " . $i . "\n";
    if ($i == 0) {
        echo "i is 0\n";
    }
    if ($i == 1) {
        echo "i is 1\n";
    }
    if ($i == 2) {
        echo "i is 2\n";
    }
}
