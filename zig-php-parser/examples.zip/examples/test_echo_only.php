<?php

echo "Test 1\n";
$test = function($x) { return $x; };
echo "Test 2\n";

?>
