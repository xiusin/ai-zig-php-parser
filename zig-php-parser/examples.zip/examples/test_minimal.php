<?php
$test = function($x) { return $x; };
?>
