<?php
// 测试echo函数调用语法
echo("Hello from echo function!");
echo("\n");
echo("Multiple", " ", "arguments", " ", "work", "!\n");
echo("Numbers: ", 1, ", ", 2, ", ", 3, "\n");
echo("Mixed: ", "string", ", ", 42, ", ", true, "\n");
